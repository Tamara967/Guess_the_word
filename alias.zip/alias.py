print("please write the question....\n")
str1 = input("")
v = ""
str2 = []
for i in range(0,len(str1)):  
  str2.extend("-")
print("please answer the question....")
while str1 != v:
  v = ""
  str3 = input("Answer the question?: \n")
  if str3.isalnum()==False or str3.isdigit():
    print("please enter one letter")
  elif len(str3)>1:
    print("please enter one letter")
  else:
      for i in range(0,len(str2)):
        if str3 in str1[i]:
          str2[i] = str3
      for i in str2:
        v += i
      print(v)
print("You win!!!")